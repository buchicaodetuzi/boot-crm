package com.itheima.core.service;

import com.itheima.core.po.User;

/**
 * 用户service层接口
 * @author Administrator
 *
 */
public interface UserService {
	//通过账号密码查询用户
	public User findUser(String usercode,String password);
}
