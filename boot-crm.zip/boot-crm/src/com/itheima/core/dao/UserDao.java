package com.itheima.core.dao;

import org.apache.ibatis.annotations.Param;

import com.itheima.core.po.User;

/**
 * 用户DAO层接口
 * @author Administrator
 *
 */
public interface UserDao {
	/**
	 * 通过账号密码查询用户
	 */
	public User findUser(@Param("usercode")String usercode,@Param("userpassword")String password);
}
